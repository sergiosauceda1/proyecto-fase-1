import React from 'react';
import Header from './components/Header';
import TaskList from './components/TaskList';
import ProjectForm from './components/ProjectForm';
import './styles/styles.css';

function App() {
  return (
    <div className="App">
      <Header />
      <ProjectForm />
      <TaskList />
    </div>
  );
}

export default App;
