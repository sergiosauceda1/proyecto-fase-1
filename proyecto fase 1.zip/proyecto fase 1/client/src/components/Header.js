import React from 'react';

const Header = () => {
  return (
    <header>
      <h1>Proyecto de Gestión de Tareas</h1>
    </header>
  );
};

export default Header;
