import React, { useState, useEffect } from 'react';
import { getProjects } from '../services/projectService';

const TaskList = () => {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    const fetchProjects = async () => {
      const projectsData = await getProjects();
      setProjects(projectsData);
    };
    fetchProjects();
  }, []);

  return (
    <div>
      <h2>Lista de Proyectos</h2>
      <ul>
        {projects.map((project, index) => (
          <li key={index}>{project.name} - {project.description}</li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
