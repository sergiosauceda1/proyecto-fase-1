import React, { useState } from 'react';
import { createProject } from '../services/projectService';

const ProjectForm = () => {
  const [project, setProject] = useState({ name: '', description: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createProject(project);
    setProject({ name: '', description: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Nombre del proyecto"
        value={project.name}
        onChange={(e) => setProject({ ...project, name: e.target.value })}
        required
      />
      <input
        type="text"
        placeholder="Descripción"
        value={project.description}
        onChange={(e) => setProject({ ...project, description: e.target.value })}
        required
      />
      <button type="submit">Crear Proyecto</button>
    </form>
  );
};

export default ProjectForm;
