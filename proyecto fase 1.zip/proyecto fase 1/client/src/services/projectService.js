import axios from 'axios';

export const getProjects = async () => {
  const response = await axios.get('http://localhost:5000/projects');
  return response.data;
};

export const createProject = async (project) => {
  const response = await axios.post('http://localhost:5000/projects', project);
  return response.data;
};
